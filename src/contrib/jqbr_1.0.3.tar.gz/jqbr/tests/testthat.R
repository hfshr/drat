library(testthat)
library(jqbr)

test_check("jqbr")
