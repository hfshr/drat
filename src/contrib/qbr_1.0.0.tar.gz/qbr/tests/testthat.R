library(testthat)
library(qbr)

test_check("qbr")
